console.log('this is my first game')
var canvas = document.querySelector('canvas')

canvas.width = innerWidth;
canvas.height = innerHeight

var ctx = canvas.getContext('2d')
var increasepos = 0;
// var time = Math.floor(Math.random() * 5000)
var mouse={
    x:0,
    y:0
}
class part {
    constructor(x, y, dx, dy, radius) {
        this.x = x;
        this.y = y;
        this.dx = dx;
        this.dy = dy;
        this.radius = radius;
        this.color = `rgb(${Math.random() * 255},${Math.random() * 255},${Math.random() * 255})`
        this.active = 2000

    }
    create = function () {
        ctx.fillStyle = this.color;
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2, false);
        ctx.fill()
    }
    update = function () {
        this.x += this.dx
        // this.y+=this.dy
        if (this.x + this.radius > innerWidth || this.x < 0) {
            this.y += this.dy;
            this.dx = -this.dx;

        }
       

        this.create()
        this.active--

    }
}
// class enem{
//     constructor(x,y,dx,dy,radius){
//         this.x=x;
//         this.y=y;
//         this.dx=dx;
//         this.dy=dy;
//         this.radius=radius;
//         this.color=`rgb(${Math.random()*255},${Math.random()*255},${Math.random()*255})`
//         this.active=500

//     }
//     create=function(){
//         ctx.fillStyle=this.color;
//         ctx.beginPath()
//         ctx.arc(this.x,this.y,this.radius,0,Math.PI*2,false);
//         ctx.fill()
//     }
//     update=function(){
//         this.x+=this.dx
//         this.y+=this.dy


//         this.create()
//         this.active--

//     }
// }

var particle = [];
// var enemies = [];
for (let i = 0; i < 4; i++) {
    let x = increasepos;
    let y = 0;
    let radius = 25;
    let dx = 2;
    let dy = 62;
    increasepos += 60
    particle.push(new part(x, y, dx, dy, radius))

}
function enemi(x,y,dx,dy,radius){
    this.x=x;
    this.y=y;
    this.dx=dx;
    this.dy=dy;
    this.active=1000;
    this.radius=radius;
    this.create=function(){
        ctx.beginPath()
        ctx.fillStyle='yellow';
        ctx.arc(this.x,this.y,this.radius,0,Math.PI*2,false);
        ctx.fill()
        // ctx.save()
    }
    this.update=function(){
        this.x+=this.dx;
        this.y-=this.dy;
        
        this.create()

        // if(this.y<0){
        //     this.x=innerWidth-this.radius;
        // }
        this.active--
    }
}
function toap(x,y,dx,dy,coord,radius){

    this.x=x;
    this.y=y;
    this.dx=dx;
    this.dy=dy;
    this.coord=coord;
    this.radius=radius;

    this.create=function(){
        ctx.beginPath()
        ctx.fillStyle='white';
        ctx.arc(this.x,this.y,this.radius,0,Math.PI*2,false);
        ctx.fill()
        // ctx.save()
    }
    this.update=function(){
        this.x+=this.dx;
        this.y+=this.dy;
        this.dx=this.coord.x;
        this.dy=this.coord.y;
        this.create()

        if(this.x+this.radius>innerWidth){
            this.x=innerWidth-this.radius;
        }
    }
}
var tops=[]
function toapcreate(){
    let x =innerWidth/2;
    let y = innerHeight-40;
    let coord={
        x:mouse.x,
        y:mouse.y
    }
    let dx=0;
    let dy=0;
    let radius=40;
    tops.push(new toap(x,y,dx,dy,coord,radius))


}
var enem=[]
window.onclick=function(e){
    let x=e.x;
    let y=innerHeight+3
    let radius=3;
    let dx=0;
    let dy=5;
    enem.push(new enemi(x,y,dx,dy,radius))

}
toapcreate()
// function fire(){
//     let enemy=10
//     let count=Math.floor(Math.random()*enemy)
//     for (let i =0 ; i<1;i++){
//         let x=particle[count].x+30;
//         let y=particle[count].y+30;
//         let dx=0;
//         let dy=5;
//         let radius=3;
//         enemies.push(new enem(x,y,dx,dy,radius))
//     }

//     let enemyinter=setInterval(fire,2000)
// }
// fire()

addEventListener('mousemove',function(e){

    mouse={
        x:e.x,
        y:e.y
    }
    tops[0].x=e.x;

//    switch(e.key){
//     case "ArrowLeft":
//         mouse.x=-4;
//         mouse.y=0;
//         break;
//     case "ArrowRight":
//         mouse.x==4;
//         mouse.y==0;
//         break;
//     default :
//     mouse.x=0;
//     mouse.y=0;
    
//    }
   
})
function check(x1,x2,y1,y2){
let xdist=y1-x1;
let ydist=y2-x2;
return Math.sqrt(Math.pow(xdist,2)+Math.pow(ydist,2))
  }
function render() {
    requestAnimationFrame(render);
//    ctx.clearRect(0, 0, innerWidth, innerHeight)
    ctx.fillStyle = 'rgba(0,0,0,0.1)';
     ctx.fillRect(0,0,innerWidth,innerHeight);
    ctx.fill()

    particle.forEach((elem, index) => {
        elem.update()
        if(elem.y>innerHeight+50){
                    particle.splice(index,1)
                 }
         for(let i =0;i<enem.length;i++){
         if(check(elem.x,elem.y,enem[i].x,enem[i].y)<elem.radius+enem[i].radius){
         particle.splice(index,1)
         enem.splice(i,1)
         }
         }

    })

    for (let i = 0; i < 4; i++) {
        if (particle[i].x + particle[i].radius > innerWidth || particle[i].x < 0) {
            for (let i = 0; i < 1; i++) {
                let x = 0;
                let y = 0;
                let radius = 25;
                let dx = 2;
                let dy = 62;
                // increasepos+=60

                particle.push(new part(x, y, dx, dy, radius))
            }
        }
    }
    tops.forEach(elem=>{
        elem.update()
    })

      enem.forEach((elem,index)=>{
        elem.update()

        if(elem.active<0){
            enem.splice(index,1)
        }
     

      })
      
    // console.log(particle)
    // console.log(enem)
//    check()
}
 render()
